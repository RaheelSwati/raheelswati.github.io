#include <jni.h>
#include <string>
#include <vector>
#include <stdexcept>
#include <memory>
#include <map>
#include <cstring>
extern "C" {
#include "libudfread/src/udfread.h"
#include <libavformat/avformat.h>
#include <libavcodec/avcodec.h>
}
struct IsoContext {
  udfread* volume=nullptr; UDFFILE* file=nullptr;
  AVIOContext* io=nullptr; AVFormatContext* format=nullptr;
  int video=-1; bool mvc=false;
  std::vector<int> tracks;
  std::vector<uint8_t> mvcHeaders;
  struct Views { std::vector<uint8_t> data[2]; int flags=0; };
  std::map<int64_t,Views> views;
  size_t bufferedViewBytes=0;
  ~IsoContext() {
    avformat_close_input(&format);
    if(io) { av_freep(&io->buffer); avio_context_free(&io); }
    if(file) udfread_file_close(file);
    if(volume) udfread_close(volume);
  }
};
static void fail(JNIEnv* env,const char* text) { env->ThrowNew(env->FindClass("java/lang/IllegalStateException"),text); }
static int readUdf(void* opaque,uint8_t* data,int size) {
  auto c=static_cast<IsoContext*>(opaque); ssize_t got=udfread_file_read(c->file,data,size);
  return got>0?int(got):got==0?AVERROR_EOF:AVERROR(EIO);
}
static int64_t seekUdf(void* opaque,int64_t offset,int whence) {
  auto c=static_cast<IsoContext*>(opaque);
  if(whence==AVSEEK_SIZE) return udfread_file_size(c->file);
  return udfread_file_seek(c->file,offset,whence&~AVSEEK_FORCE);
}
static std::string singleClip(udfread* volume,const char* path,const char* suffix) {
  UDFDIR* dir=udfread_opendir(volume,path); if(!dir) return "";
  udfread_dirent entry; std::string chosen;
  while(udfread_readdir(dir,&entry)) {
    std::string name=entry.d_name;
    if(name.size()<strlen(suffix)||name.substr(name.size()-strlen(suffix))!=suffix) continue;
    if(!chosen.empty()) { udfread_closedir(dir); throw std::runtime_error("Multi-clip Blu-ray images require playlist support; open a remux instead"); }
    chosen=std::string(path)+"/"+name;
  }
  udfread_closedir(dir); return chosen;
}
static const char* mime(const AVCodecParameters* p,bool mvc) {
  switch(p->codec_id) {
    case AV_CODEC_ID_H264: return mvc?"video/x-vistalyra-mvc":"video/avc";
    case AV_CODEC_ID_HEVC: return "video/hevc";
    case AV_CODEC_ID_AC3: return "audio/ac3";
    case AV_CODEC_ID_EAC3: return "audio/eac3";
    case AV_CODEC_ID_DTS: return "audio/vnd.dts";
    case AV_CODEC_ID_TRUEHD: return "audio/true-hd";
    case AV_CODEC_ID_MP2: case AV_CODEC_ID_MP3: return "audio/mpeg";
    case AV_CODEC_ID_PCM_BLURAY: return "audio/raw";
    default: return nullptr;
  }
}
#define ISO_METHOD(name) Java_com_cineverse_vr_player_IsoNative_##name
extern "C" JNIEXPORT jlong JNICALL ISO_METHOD(open)(JNIEnv* env,jclass,jint fd) {
  try {
    auto c=std::make_unique<IsoContext>(); c->volume=udfread_init();
    std::string path="/proc/self/fd/"+std::to_string(fd);
    if(!c->volume||udfread_open(c->volume,path.c_str())<0) throw std::runtime_error("Not a readable UDF disc image");
    UDFDIR* aacs=udfread_opendir(c->volume,"/AACS");
    if(aacs) { udfread_closedir(aacs); throw std::runtime_error("Protected Blu-ray images are not supported"); }
    auto clip=singleClip(c->volume,"/BDMV/STREAM/SSIF",".ssif"); c->mvc=!clip.empty();
    if(clip.empty()) clip=singleClip(c->volume,"/BDMV/STREAM",".m2ts");
    if(clip.empty()) throw std::runtime_error("No single-clip Blu-ray stream found");
    c->file=udfread_file_open(c->volume,clip.c_str()); if(!c->file) throw std::runtime_error("Cannot open disc stream");
    auto buffer=static_cast<uint8_t*>(av_malloc(32768)); if(!buffer) throw std::bad_alloc();
    c->io=avio_alloc_context(buffer,32768,0,c.get(),readUdf,nullptr,seekUdf);
    if(!c->io) { av_free(buffer); throw std::bad_alloc(); }
    c->format=avformat_alloc_context(); if(!c->format) throw std::bad_alloc();
    c->format->pb=c->io; c->format->flags|=AVFMT_FLAG_CUSTOM_IO;
    c->format->probesize=4*1024*1024; c->format->max_analyze_duration=2000000;
    if(avformat_open_input(&c->format,nullptr,av_find_input_format("mpegts"),nullptr)<0||avformat_find_stream_info(c->format,nullptr)<0)
      throw std::runtime_error("Cannot demux Blu-ray transport stream");
    for(unsigned i=0;i<c->format->nb_streams;i++) {
      auto p=c->format->streams[i]->codecpar;
      if(p->codec_type==AVMEDIA_TYPE_VIDEO&&p->width>0&&c->video<0) c->video=int(i);
    }
    if(c->video<0) throw std::runtime_error("No supported Blu-ray video track");
    if(!mime(c->format->streams[c->video]->codecpar,c->mvc)) throw std::runtime_error("This disc video codec is not supported");
    c->tracks.push_back(c->video);
    for(unsigned i=0;i<c->format->nb_streams;i++) {
      auto p=c->format->streams[i]->codecpar;
      if(p->codec_type!=AVMEDIA_TYPE_AUDIO) continue;
      if(!mime(p,false)||p->sample_rate<=0||p->ch_layout.nb_channels<=0)
        throw std::runtime_error("This disc audio needs additional demux support; open a remux instead");
      c->tracks.push_back(int(i));
    }
    c->format->flags|=AVFMT_FLAG_NOPARSE|AVFMT_FLAG_NOFILLIN;
    // Both transport-stream PIDs have parameter sets. Initialize MVC with the
    // dependent subset SPS too, before any base-view frame can be output as 2D.
    if(c->mvc) {
      avio_seek(c->io,0,SEEK_SET); avformat_flush(c->format);
      AVPacket* probe=av_packet_alloc(); bool subset=false;
      if(!probe) throw std::bad_alloc();
      for(int n=0;n<2048&&!subset&&av_read_frame(c->format,probe)>=0;n++) {
        auto p=c->format->streams[probe->stream_index]->codecpar;
        if(p->codec_id==AV_CODEC_ID_H264) {
          for(int i=0;i+4<probe->size;i++) {
            if(probe->data[i]||probe->data[i+1]||probe->data[i+2]!=1) continue;
            int type=probe->data[i+3]&31;
            if(type!=7&&type!=8&&type!=15) continue;
            int end=i+4;
            while(end+3<probe->size&&(probe->data[end]||probe->data[end+1]||probe->data[end+2]!=1)) end++;
            if(end+3>=probe->size) end=probe->size;
            if(c->mvcHeaders.size()+end-i>65536) { av_packet_free(&probe); throw std::runtime_error("Disc parameter sets exceed limit"); }
            c->mvcHeaders.insert(c->mvcHeaders.end(),probe->data+i,probe->data+end);
            if(type==15) subset=true;
            i=end-1;
          }
        }
        av_packet_unref(probe);
      }
      av_packet_free(&probe);
      if(!subset) throw std::runtime_error("Disc MVC subset parameter set not found");
    }
    avio_seek(c->io,0,SEEK_SET); avformat_flush(c->format);
    return reinterpret_cast<jlong>(c.release());
  } catch(const std::exception& e) { fail(env,e.what()); return 0; }
}
extern "C" JNIEXPORT jobjectArray JNICALL ISO_METHOD(tracks)(JNIEnv* env,jclass,jlong handle) {
  if(!handle) { fail(env,"Disc reader is closed"); return nullptr; }
  auto c=reinterpret_cast<IsoContext*>(handle); jclass cls=env->FindClass("com/cineverse/vr/player/IsoTrack");
  auto ctor=env->GetMethodID(cls,"<init>","(ILjava/lang/String;IIII[B)V");
  auto result=env->NewObjectArray(c->tracks.size(),cls,nullptr);
  int index=0;
  for(int id:c->tracks) {
    auto p=c->format->streams[id]->codecpar;
    bool useMvc=c->mvc&&id==c->video;
    int extraSize=useMvc?int(c->mvcHeaders.size()):p->extradata_size;
    auto type=env->NewStringUTF(mime(p,c->mvc)); auto extra=env->NewByteArray(extraSize);
    if(extraSize) env->SetByteArrayRegion(extra,0,extraSize,reinterpret_cast<jbyte*>(useMvc?c->mvcHeaders.data():p->extradata));
    auto track=env->NewObject(cls,ctor,id,type,p->width,p->height,p->sample_rate,p->ch_layout.nb_channels,extra);
    env->SetObjectArrayElement(result,index++,track); env->DeleteLocalRef(type); env->DeleteLocalRef(extra); env->DeleteLocalRef(track);
  }
  return result;
}
extern "C" JNIEXPORT jlong JNICALL ISO_METHOD(durationUs)(JNIEnv*,jclass,jlong handle) {
  if(!handle) return 0;
  return reinterpret_cast<IsoContext*>(handle)->format->duration;
}
extern "C" JNIEXPORT jobject JNICALL ISO_METHOD(read)(JNIEnv* env,jclass,jlong handle) {
  if(!handle) { fail(env,"Disc reader is closed"); return nullptr; }
  auto c=reinterpret_cast<IsoContext*>(handle); AVPacket* packet=av_packet_alloc(); if(!packet) { fail(env,"Packet allocation failed"); return nullptr; }
  int readResult;
  while((readResult=av_read_frame(c->format,packet))>=0) {
    auto stream=c->format->streams[packet->stream_index]; auto p=stream->codecpar;
    int id=packet->stream_index;
    if(c->mvc&&p->codec_id==AV_CODEC_ID_H264) id=c->video;
    bool included=false; for(int track:c->tracks) if(track==id) included=true;
    if(!included) { av_packet_unref(packet); continue; }
    int64_t pts=packet->pts==AV_NOPTS_VALUE?packet->dts:packet->pts;
    if(pts==AV_NOPTS_VALUE) { av_packet_unref(packet); continue; }
    int64_t timestamp=av_rescale_q(pts,stream->time_base,AVRational{1,1000000});
    if(c->format->start_time!=AV_NOPTS_VALUE) timestamp-=c->format->start_time;
    if(c->mvc&&p->codec_id==AV_CODEC_ID_H264) {
      auto& pair=c->views[timestamp]; int eye=packet->stream_index==c->video?0:1;
      c->bufferedViewBytes+=packet->size;
      if(c->bufferedViewBytes>32*1024*1024||packet->size>8*1024*1024) {
        av_packet_free(&packet); fail(env,"Disc view buffering exceeds 32 MB limit"); return nullptr;
      }
      pair.data[eye].insert(pair.data[eye].end(),packet->data,packet->data+packet->size);
      if(eye==0) {
        pair.flags=packet->flags;
        for(int n=0;n+3<packet->size;n++)
          if(packet->data[n]==0&&packet->data[n+1]==0&&packet->data[n+2]==1&&(packet->data[n+3]&31)==5)
            pair.flags|=AV_PKT_FLAG_KEY;
      }
      if(pair.data[0].empty()||pair.data[1].empty()) {
        if(c->views.size()>2048) { av_packet_free(&packet); fail(env,"Disc MVC views do not match within buffering limit"); return nullptr; }
        av_packet_unref(packet); continue;
      }
      pair.data[0].insert(pair.data[0].end(),pair.data[1].begin(),pair.data[1].end());
      c->bufferedViewBytes-=pair.data[0].size();
      std::vector<uint8_t> combined=std::move(pair.data[0]); int flags=pair.flags;
      c->views.erase(timestamp);
      auto data=env->NewByteArray(combined.size()); env->SetByteArrayRegion(data,0,combined.size(),reinterpret_cast<const jbyte*>(combined.data()));
      auto cls=env->FindClass("com/cineverse/vr/player/IsoPacket"); auto ctor=env->GetMethodID(cls,"<init>","(IJI[B)V");
      auto result=env->NewObject(cls,ctor,c->video,timestamp,flags&AV_PKT_FLAG_KEY?1:0,data);
      env->DeleteLocalRef(data); env->DeleteLocalRef(cls); av_packet_free(&packet); return result;
    }
    std::vector<uint8_t> converted;
    const uint8_t* bytes=packet->data; int size=packet->size;
    if(p->codec_id==AV_CODEC_ID_PCM_BLURAY) {
      // Blu-ray LPCM carries a four-byte header and big-endian samples. This
      // first path supports stereo 16-bit only; do not mislabel packed 24-bit.
      if(size<4||(bytes[3]>>6)!=1||p->ch_layout.nb_channels!=2) {
        av_packet_free(&packet); fail(env,"Disc LPCM currently requires stereo 16-bit"); return nullptr;
      }
      size-=4; converted.resize(size); bytes+=4;
      if(size&1) { av_packet_free(&packet); fail(env,"Truncated LPCM packet"); return nullptr; }
      for(int i=0;i<size;i+=2) { converted[i]=bytes[i+1]; converted[i+1]=bytes[i]; }
      bytes=converted.data();
    }
    auto data=env->NewByteArray(size); env->SetByteArrayRegion(data,0,size,reinterpret_cast<const jbyte*>(bytes));
    auto cls=env->FindClass("com/cineverse/vr/player/IsoPacket");
    auto ctor=env->GetMethodID(cls,"<init>","(IJI[B)V");
    auto result=env->NewObject(cls,ctor,id,timestamp,packet->flags&AV_PKT_FLAG_KEY?1:0,data);
    env->DeleteLocalRef(data); env->DeleteLocalRef(cls); av_packet_free(&packet); return result;
  }
  av_packet_free(&packet);
  if(readResult!=AVERROR_EOF) fail(env,"Disc read failed; image may be damaged or inaccessible");
  return nullptr;
}
extern "C" JNIEXPORT void JNICALL ISO_METHOD(seek)(JNIEnv* env,jclass,jlong handle,jlong timeUs) {
  if(!handle) { fail(env,"Disc reader is closed"); return; }
  auto c=reinterpret_cast<IsoContext*>(handle);
  c->views.clear();
  c->bufferedViewBytes=0;
  int64_t start=c->format->start_time==AV_NOPTS_VALUE?0:c->format->start_time;
  if(av_seek_frame(c->format,-1,timeUs+start,AVSEEK_FLAG_BACKWARD)<0) fail(env,"Disc seek failed");
}
extern "C" JNIEXPORT void JNICALL ISO_METHOD(close)(JNIEnv*,jclass,jlong handle) { delete reinterpret_cast<IsoContext*>(handle); }
