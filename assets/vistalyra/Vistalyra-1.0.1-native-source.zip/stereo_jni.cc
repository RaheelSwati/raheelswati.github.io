#include <jni.h>
#include <android/native_window_jni.h>
#include <deque>
#include <map>
#include <vector>
#include <stdexcept>
#include <cstring>
#include <memory>
#include <atomic>
#include "../experimental/mvc/edge264-mvc/edge264mvc.h"
extern "C" {
#include <libavcodec/avcodec.h>
#include <libavutil/opt.h>
#include <libavutil/stereo3d.h>
}
struct Picture { int w,h; int64_t pts; std::vector<uint8_t> yuv; };
struct Context {
  std::atomic<bool> unknownEyeOrder{false};
  Edge264MvcDecoder* mvc=nullptr;
  AVCodecContext* hevc=nullptr;
  std::deque<Picture> ready;
  struct Pair { AVFrame* eyes[2]={nullptr,nullptr}; };
  std::map<int64_t,Pair> pending;
  ~Context() {
    edge264mvc_close(&mvc); avcodec_free_context(&hevc);
    for (auto& entry:pending) for(auto& eye:entry.second.eyes) av_frame_free(&eye);
  }
};
static void error(JNIEnv* env,const char* message) { env->ThrowNew(env->FindClass("java/lang/IllegalStateException"),message); }
static void plane(uint8_t* dst,int dstStride,const uint8_t* src,int srcStride,int width,int height,int bits) {
  for(int y=0;y<height;y++) {
    if(bits==8) memcpy(dst+y*dstStride,src+y*srcStride,width);
    else { auto row=reinterpret_cast<const uint16_t*>(src+y*srcStride); for(int x=0;x<width;x++) dst[y*dstStride+x]=row[x]>>(bits-8); }
  }
}
static Picture pack(int w,int h,int64_t pts,const uint8_t* const* left,const uint8_t* const* right,
                    const int* ls,const int* rs,int bits) {
  if(w<=0||h<=0||w>2048||h>1536||(w&1)||(h&1)||(bits!=8&&bits!=10))
    throw std::runtime_error("Stereo fallback supports even-sized 8/10-bit 4:2:0 views up to 2048x1536");
  Picture result{w*2,h,pts,{}}; result.yuv.resize(size_t(w)*h*3);
  size_t offset=0;
  for(int p=0;p<3;p++) {
    int pw=p? w/2:w, ph=p?h/2:h, stride=pw*2;
    if(!left[p]||!right[p]) throw std::runtime_error("Missing stereo plane");
    plane(result.yuv.data()+offset,stride,left[p],ls[p],pw,ph,bits);
    plane(result.yuv.data()+offset+pw,stride,right[p],rs[p],pw,ph,bits);
    offset+=size_t(stride)*ph;
  }
  return result;
}
static void mvcDrain(Context* c) {
  Edge264MvcFrame frame;
  while(edge264mvc_receive_frame(c->mvc,&frame)==EDGE264MVC_OK) {
    try {
      if(!frame.views[1].planes[0]) throw std::runtime_error("MVC dependent view is missing; stereo cannot be displayed");
      if(frame.width_C!=frame.width_Y/2||frame.height_C!=frame.height_Y/2) throw std::runtime_error("MVC chroma layout unsupported");
      int strides[3]={frame.stride_Y,frame.stride_C,frame.stride_C};
      c->ready.push_back(pack(frame.width_Y,frame.height_Y,frame.views[0].pts,
        frame.views[0].planes,frame.views[1].planes,strides,strides,frame.bit_depth_Y));
      edge264mvc_release_frame(c->mvc,&frame);
    } catch(...) { edge264mvc_release_frame(c->mvc,&frame); throw; }
    if(c->ready.size()>16) throw std::runtime_error("Stereo output queue limit exceeded");
  }
}
static void hevcDrain(Context* c) {
  AVFrame* frame=av_frame_alloc();
  if(!frame) throw std::bad_alloc();
  try {
    int status;
    while((status=avcodec_receive_frame(c->hevc,frame))>=0) {
      auto sd=av_frame_get_side_data(frame,AV_FRAME_DATA_STEREO3D);
      int eye=-1;
      if(sd) {
        auto stereo=reinterpret_cast<AVStereo3D*>(sd->data);
        if(stereo->view==AV_STEREO3D_VIEW_LEFT) eye=0;
        if(stereo->view==AV_STEREO3D_VIEW_RIGHT) eye=1;
      }
      if(eye<0) {
        auto view=av_frame_get_side_data(frame,AV_FRAME_DATA_VIEW_ID);
        if(view&&view->size>=sizeof(int)) {
          int id=*reinterpret_cast<int*>(view->data);
          if(id==0||id==1) { eye=id; c->unknownEyeOrder.store(true); }
        }
        if(eye<0) throw std::runtime_error("MV-HEVC view IDs cannot be paired");
      }
      if(frame->format!=AV_PIX_FMT_YUV420P&&frame->format!=AV_PIX_FMT_YUV420P10LE)
        throw std::runtime_error("MV-HEVC chroma layout unsupported");
      auto& pair=c->pending[frame->pts];
      if(pair.eyes[eye]) throw std::runtime_error("Duplicate MV-HEVC view timestamp");
      pair.eyes[eye]=av_frame_clone(frame);
      if(!pair.eyes[eye]) throw std::bad_alloc();
      if(pair.eyes[0]&&pair.eyes[1]) {
        auto a=pair.eyes[0],b=pair.eyes[1];
        if(a->width!=b->width||a->height!=b->height||a->format!=b->format) throw std::runtime_error("MV-HEVC views have different geometry");
        c->ready.push_back(pack(a->width,a->height,a->pts,a->data,b->data,a->linesize,b->linesize,
                              a->format==AV_PIX_FMT_YUV420P?8:10));
        av_frame_free(&pair.eyes[0]); av_frame_free(&pair.eyes[1]); c->pending.erase(frame->pts);
      }
      av_frame_unref(frame);
      if(c->pending.size()>16||c->ready.size()>16) throw std::runtime_error("MV-HEVC pairing queue limit exceeded");
    }
    if(status!=AVERROR(EAGAIN)&&status!=AVERROR_EOF) throw std::runtime_error("MV-HEVC decode failed");
    av_frame_free(&frame);
  } catch(...) { av_frame_free(&frame); throw; }
}
#define JNI_METHOD(name) Java_com_cineverse_vr_player_StereoNative_##name
extern "C" JNIEXPORT jlong JNICALL JNI_METHOD(open)(JNIEnv* env,jclass,jboolean mvc) {
  try {
    auto c=std::make_unique<Context>();
    if(mvc) {
      Edge264MvcSettings s; edge264mvc_default_settings(&s); s.n_threads=4; s.max_frame_pixels=1920*1088;
      if(edge264mvc_open(&c->mvc,&s)!=EDGE264MVC_OK) throw std::runtime_error("Cannot initialize MVC decoder");
    } else {
      c->hevc=avcodec_alloc_context3(avcodec_find_decoder(AV_CODEC_ID_HEVC));
      if(!c->hevc) throw std::bad_alloc();
      c->hevc->thread_count=4; c->hevc->pkt_timebase={1,1000000};
      if(av_opt_set(c->hevc,"view_ids","-1",AV_OPT_SEARCH_CHILDREN)<0||avcodec_open2(c->hevc,nullptr,nullptr)<0)
        throw std::runtime_error("Cannot initialize multiview HEVC decoder");
    }
    return reinterpret_cast<jlong>(c.release());
  } catch(const std::exception& e) { error(env,e.what()); return 0; }
}
extern "C" JNIEXPORT void JNICALL JNI_METHOD(feed)(JNIEnv* env,jclass,jlong handle,jobject input,jint size,jlong pts,jboolean eos) {
  try {
    auto c=reinterpret_cast<Context*>(handle);
    auto data=input?static_cast<uint8_t*>(env->GetDirectBufferAddress(input)):nullptr;
    if(!c||size<0||size>8*1024*1024||(!eos&&(!data||env->GetDirectBufferCapacity(input)<size)))
      throw std::runtime_error("Invalid stereo packet");
    if(c->mvc) {
      if(eos) edge264mvc_send_end(c->mvc);
      else {
        size_t pos=edge264mvc_find_start_code(data,size);
        if(pos==size) throw std::runtime_error("MVC requires Annex B access units");
        while(pos+3<size_t(size)) {
          size_t begin=pos+3,next=begin+edge264mvc_find_start_code(data+begin,size-begin),end=next;
          while(end>begin&&data[end-1]==0) end--;
          int status;
          while((status=edge264mvc_send_nal(c->mvc,data+begin,end-begin,pts,0))==EDGE264MVC_AGAIN) mvcDrain(c);
          int type=data[begin]&31;
          // Blu-ray may carry reserved non-picture NALs. The decoder API
          // explicitly permits skipping these; never ignore rejected slices.
          if(status<0 && !(status==EDGE264MVC_UNSUPPORTED&&(type==0||type>=24)))
            throw std::runtime_error("MVC packet rejected: status="+std::to_string(status)+" NAL="+std::to_string(type)+" bytes="+std::to_string(end-begin));
          mvcDrain(c); pos=next;
        }
      }
      mvcDrain(c);
    } else {
      AVPacket* packet=nullptr;
      if(!eos) { packet=av_packet_alloc(); if(!packet||av_new_packet(packet,size)<0) { av_packet_free(&packet); throw std::bad_alloc(); }
        memcpy(packet->data,data,size); packet->pts=pts; packet->dts=AV_NOPTS_VALUE; }
      int status=avcodec_send_packet(c->hevc,packet);
      if(status==AVERROR(EAGAIN)) { hevcDrain(c); status=avcodec_send_packet(c->hevc,packet); }
      av_packet_free(&packet);
      if(status<0&&status!=AVERROR_EOF) throw std::runtime_error("MV-HEVC packet rejected");
      hevcDrain(c);
      if(eos&&!c->pending.empty()) throw std::runtime_error("MV-HEVC ends with unmatched views");
    }
  } catch(const std::exception& e) { error(env,e.what()); }
}
extern "C" JNIEXPORT jboolean JNICALL JNI_METHOD(take)(JNIEnv* env,jclass,jlong handle,jobject output) {
  auto c=reinterpret_cast<Context*>(handle); if(!c||c->ready.empty()) return false;
  auto& p=c->ready.front(); jclass cls=env->GetObjectClass(output);
  auto init=env->GetMethodID(cls,"init","(JILjava/nio/ByteBuffer;)V");
  env->CallVoidMethod(output,init,p.pts,0,nullptr);
  auto allocate=env->GetMethodID(cls,"initForYuvFrame","(IIIII)Z");
  if(!env->CallBooleanMethod(output,allocate,p.w,p.h,p.w,p.w/2,2)||env->ExceptionCheck()) return false;
  jobject data=env->GetObjectField(output,env->GetFieldID(cls,"data","Ljava/nio/ByteBuffer;"));
  void* dst=env->GetDirectBufferAddress(data);
  if(!dst||env->GetDirectBufferCapacity(data)<jlong(p.yuv.size())) { error(env,"Stereo output allocation failed"); return false; }
  memcpy(dst,p.yuv.data(),p.yuv.size()); env->DeleteLocalRef(data); env->DeleteLocalRef(cls);
  c->ready.pop_front(); return true;
}
extern "C" JNIEXPORT void JNICALL JNI_METHOD(flush)(JNIEnv*,jclass,jlong handle) {
  auto c=reinterpret_cast<Context*>(handle); if(!c) return;
  c->ready.clear(); for(auto& entry:c->pending) for(auto& eye:entry.second.eyes) av_frame_free(&eye); c->pending.clear();
  if(c->mvc) edge264mvc_flush(c->mvc); else avcodec_flush_buffers(c->hevc);
}
extern "C" JNIEXPORT void JNICALL JNI_METHOD(close)(JNIEnv*,jclass,jlong handle) { delete reinterpret_cast<Context*>(handle); }
extern "C" JNIEXPORT jboolean JNICALL JNI_METHOD(eyeOrderUnknown)(JNIEnv*,jclass,jlong handle) {
  return handle&&reinterpret_cast<Context*>(handle)->unknownEyeOrder.load();
}
extern "C" JNIEXPORT void JNICALL JNI_METHOD(render)(JNIEnv* env,jclass,jobject data,jint w,jint h,jobject surface) {
  auto src=static_cast<uint8_t*>(env->GetDirectBufferAddress(data));
  if(!src||w<=0||h<=0||env->GetDirectBufferCapacity(data)<int64_t(w)*h*3/2) { error(env,"Invalid stereo image"); return; }
  ANativeWindow* window=ANativeWindow_fromSurface(env,surface); if(!window) { error(env,"Invalid stereo surface"); return; }
  ANativeWindow_Buffer buf;
  if(ANativeWindow_setBuffersGeometry(window,w,h,0x32315659)||ANativeWindow_lock(window,&buf,nullptr)) {
    ANativeWindow_release(window); error(env,"Cannot lock stereo surface"); return;
  }
  auto dst=static_cast<uint8_t*>(buf.bits); int uvStride=((buf.stride/2+15)/16)*16;
  plane(dst,buf.stride,src,w,w,h,8);
  plane(dst+buf.stride*h,uvStride,src+w*h*5/4,w/2,w/2,h/2,8);
  plane(dst+buf.stride*h+uvStride*h/2,uvStride,src+w*h,w/2,w/2,h/2,8);
  int status=ANativeWindow_unlockAndPost(window); ANativeWindow_release(window);
  if(status) error(env,"Cannot present stereo surface");
}
