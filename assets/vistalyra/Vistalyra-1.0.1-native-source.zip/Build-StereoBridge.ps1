param([string]$NdkPath = "$PSScriptRoot/ndk")
$ErrorActionPreference = 'Stop'
$taskRoot = Split-Path $PSScriptRoot -Parent
Push-Location $taskRoot
try {
    $taskCompiler = Join-Path $NdkPath 'toolchains/llvm/prebuilt/windows-x86_64/bin/clang++.exe'
    $taskStrip = Join-Path $NdkPath 'toolchains/llvm/prebuilt/windows-x86_64/bin/llvm-strip.exe'
    $taskOutput = Join-Path $PSScriptRoot 'stereo-build'
    New-Item -ItemType Directory -Force $taskOutput | Out-Null
    foreach ($taskSource in @('stereo_jni','iso_jni')) {
        & $taskCompiler --target=aarch64-linux-android32 -std=c++17 -O2 -g -fPIC -I native-codecs/install-video-arm64/include -c "native-codecs/$taskSource.cc" -o "$taskOutput/$taskSource.o"
        if ($LASTEXITCODE -ne 0) { throw "Native compilation failed: $taskSource" }
    }
    & $taskCompiler --target=aarch64-linux-android32 -shared "$taskOutput/stereo_jni.o" "$taskOutput/iso_jni.o" experimental/mvc/output/libedge264mvc.so native-codecs/libudfread.so native-codecs/install-video-arm64/lib/libavformat.a native-codecs/install-video-arm64/lib/libavcodec.a native-codecs/install-video-arm64/lib/libavutil.a -landroid -llog -lz -lm '-Wl,--exclude-libs,ALL' '-Wl,-z,max-page-size=16384' '-Wl,-soname,libvistalyraStereo.so' -static-libstdc++ -o "$taskOutput/libvistalyraStereo.so"
    if ($LASTEXITCODE -ne 0) { throw 'Stereo bridge linking failed' }
    Copy-Item "$taskOutput/libvistalyraStereo.so" media-engine/src/main/jniLibs/arm64-v8a/
    & $taskStrip --strip-unneeded media-engine/src/main/jniLibs/arm64-v8a/libvistalyraStereo.so
    if ($LASTEXITCODE -ne 0) { throw 'Stereo bridge stripping failed' }
    # Objects are retained so recipients can relink the LGPL FFmpeg component.
} finally { Pop-Location }
