package com.cineverse.vr.player

import android.net.Uri
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.extractor.*

/** Retains stock container/audio/subtitle demuxing; routes confirmed MVC CSD or
 * explicit multiview filenames to a decoder that produces both views. */
@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
class StereoExtractorsFactory(private val context: android.content.Context? = null) : ExtractorsFactory {
    private val normal = DefaultExtractorsFactory().setConstantBitrateSeekingEnabled(true)
    override fun createExtractors(): Array<Extractor> = wrap(normal.createExtractors(), null)
    override fun createExtractors(uri: Uri, responseHeaders: Map<String, List<String>>): Array<Extractor> {
        val name = (if (context != null && uri.scheme == "content") runCatching {
            checkNotNull(context).contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if(it.moveToFirst()) it.getString(0) else null
            }
        }.getOrNull() else null).orEmpty().ifBlank { uri.lastPathSegment.orEmpty() }.lowercase(java.util.Locale.ROOT)
        if (context != null && name.endsWith(".iso") && uri.scheme in listOf("file", "content"))
            return arrayOf(IsoExtractor(context, uri))
        val hint = when {
            Regex("(?:^|[_. -])mvc(?:[_. -]|$)").containsMatchIn(name) -> StereoDecoder.MVC_MIME
            "mvhevc" in name || "mv-hevc" in name -> StereoDecoder.MVHEVC_MIME
            else -> null
        }
        return wrap(normal.createExtractors(uri, responseHeaders), hint)
    }
    private fun wrap(extractors: Array<Extractor>, hint: String?) = extractors.map { delegate ->
        object : Extractor by delegate {
            override fun init(output: ExtractorOutput) {
                delegate.init(object : ExtractorOutput by output {
                    override fun track(id: Int, type: Int): TrackOutput {
                        val target = output.track(id, type)
                        if (type != C.TRACK_TYPE_VIDEO) return target
                        return object : TrackOutput by target {
                            override fun format(format: Format) {
                                val hasSubsetSps = format.initializationData.any { bytes ->
                                    bytes.size > 4 && bytes[0] == 0.toByte() && bytes[1] == 0.toByte() &&
                                        bytes[2] == 0.toByte() && bytes[3] == 1.toByte() && (bytes[4].toInt() and 31) == 15
                                }
                                val mime = when {
                                    format.sampleMimeType == "video/avc" && (hasSubsetSps || hint == StereoDecoder.MVC_MIME) -> StereoDecoder.MVC_MIME
                                    format.sampleMimeType == "video/mv-hevc" ||
                                        (format.sampleMimeType == "video/hevc" && hint == StereoDecoder.MVHEVC_MIME) -> StereoDecoder.MVHEVC_MIME
                                    else -> null
                                }
                                target.format(if (mime == null) format else format.buildUpon()
                                    .setSampleMimeType(mime).setStereoMode(C.STEREO_MODE_LEFT_RIGHT).build())
                            }
                        }
                    }
                })
            }
        }
    }.toTypedArray<Extractor>()
}
