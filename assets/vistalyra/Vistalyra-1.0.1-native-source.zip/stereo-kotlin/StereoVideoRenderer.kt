package com.cineverse.vr.player

import android.os.Handler
import android.view.Surface
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.decoder.CryptoConfig
import androidx.media3.decoder.VideoDecoderOutputBuffer
import androidx.media3.exoplayer.RendererCapabilities
import androidx.media3.exoplayer.video.DecoderVideoRenderer
import androidx.media3.exoplayer.video.VideoRendererEventListener

@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
class StereoVideoRenderer(private val handler: Handler, listener: VideoRendererEventListener,
                          private val onWarning: (String) -> Unit = {}) :
    DecoderVideoRenderer(5000, handler, listener, 50) {
    private var decoder: StereoDecoder? = null
    private var warned = false
    override fun getName() = "VistalyraStereoVideoRenderer"
    override fun supportsFormat(format: Format): Int {
        if (format.sampleMimeType !in listOf(StereoDecoder.MVC_MIME, StereoDecoder.MVHEVC_MIME))
            return RendererCapabilities.create(C.FORMAT_UNSUPPORTED_TYPE)
        if (format.cryptoType != C.CRYPTO_TYPE_NONE) return RendererCapabilities.create(C.FORMAT_UNSUPPORTED_DRM)
        return RendererCapabilities.create(C.FORMAT_HANDLED)
    }
    override fun createDecoder(format: Format, cryptoConfig: CryptoConfig?): StereoDecoder =
        StereoDecoder(format).also { decoder = it; warned = false }
    override fun setDecoderOutputMode(outputMode: Int) { decoder?.setOutputMode(outputMode) }
    override fun renderOutputBufferToSurface(output: VideoDecoderOutputBuffer, surface: Surface) {
        if (!warned && decoder?.eyeOrderUnknown() == true) {
            warned = true
            handler.post { onWarning("This spatial video does not identify its left and right eyes. If the depth looks wrong, use Swap eyes in video settings.") }
        }
        try { StereoNative.render(checkNotNull(output.data), output.width, output.height, surface) }
        finally { output.release() }
    }
}
