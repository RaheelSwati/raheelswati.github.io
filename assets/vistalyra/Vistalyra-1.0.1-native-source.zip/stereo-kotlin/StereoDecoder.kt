package com.cineverse.vr.player

import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.decoder.Decoder
import androidx.media3.decoder.DecoderException
import androidx.media3.decoder.DecoderInputBuffer
import androidx.media3.decoder.VideoDecoderOutputBuffer
import java.util.ArrayDeque

class StereoDecodeException(message: String, cause: Throwable? = null) : DecoderException(message, cause)

/** Two-view software fallback. Output is full SBS, never a duplicated base view. */
@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
class StereoDecoder(private val format: Format) : Decoder<DecoderInputBuffer, VideoDecoderOutputBuffer, StereoDecodeException> {
    private val lock = Object()
    private val freeInputs = ArrayDeque<DecoderInputBuffer>()
    private val inputs = ArrayDeque<DecoderInputBuffer>()
    private val freeOutputs = ArrayDeque<VideoDecoderOutputBuffer>()
    private val outputs = ArrayDeque<VideoDecoderOutputBuffer>()
    private var leasedInput: DecoderInputBuffer? = null
    private var released = false
    private var reset = true
    private var generation = 0
    private var outputStart = Long.MIN_VALUE
    private var failure: StereoDecodeException? = null
    private var mode = C.VIDEO_OUTPUT_MODE_SURFACE_YUV
    private val context = StereoNative.open(format.sampleMimeType == MVC_MIME)
    private val worker: Thread
    init {
        repeat(4) {
            freeInputs.add(DecoderInputBuffer(DecoderInputBuffer.BUFFER_REPLACEMENT_MODE_DIRECT))
            freeOutputs.add(VideoDecoderOutputBuffer { buffer ->
                synchronized(lock) { buffer.clear(); freeOutputs.add(buffer); lock.notifyAll() }
            })
        }
        worker = Thread({ work() }, "Vistalyra-stereo-decoder").apply { start() }
    }
    override fun getName() = if (format.sampleMimeType == MVC_MIME) "edge264-mvc" else "ffmpeg-mvhevc"
    override fun setOutputStartTimeUs(timeUs: Long) { synchronized(lock) { outputStart = timeUs } }
    fun setOutputMode(value: Int) { synchronized(lock) { mode = value } }
    fun eyeOrderUnknown() = StereoNative.eyeOrderUnknown(context)
    private fun checkFailure() { failure?.let { throw it } }
    override fun dequeueInputBuffer(): DecoderInputBuffer? = synchronized(lock) {
        checkFailure(); check(leasedInput == null)
        freeInputs.poll()?.also { it.clear(); leasedInput = it }
    }
    override fun queueInputBuffer(input: DecoderInputBuffer) { synchronized(lock) {
        checkFailure(); check(input === leasedInput); leasedInput = null
        inputs.add(input); lock.notifyAll()
    } }
    override fun dequeueOutputBuffer(): VideoDecoderOutputBuffer? = synchronized(lock) { checkFailure(); outputs.poll() }
    override fun flush() { synchronized(lock) {
        generation++; reset = true; outputStart = Long.MIN_VALUE
        leasedInput?.let { freeInputs.add(it); leasedInput = null }
        while (inputs.isNotEmpty()) freeInputs.add(inputs.remove())
        while (outputs.isNotEmpty()) outputs.remove().release()
        lock.notifyAll()
    } }
    override fun release() {
        synchronized(lock) { released = true; lock.notifyAll() }
        worker.join()
        StereoNative.close(context)
    }
    private fun work() {
        try {
            while (true) {
                val input: DecoderInputBuffer
                val version: Int
                val shouldReset: Boolean
                synchronized(lock) {
                    while (!released && inputs.isEmpty()) lock.wait()
                    if (released) return
                    input = inputs.remove(); version = generation; shouldReset = reset; reset = false
                }
                if (shouldReset) {
                    StereoNative.flush(context)
                    format.initializationData.forEach { bytes ->
                        val data = java.nio.ByteBuffer.allocateDirect(bytes.size).put(bytes).apply { flip() }
                        StereoNative.feed(context, data, bytes.size, 0, false)
                    }
                }
                val eos = input.isEndOfStream
                StereoNative.feed(context, input.data, input.data?.remaining() ?: 0, input.timeUs, eos)
                synchronized(lock) { input.clear(); freeInputs.add(input); lock.notifyAll() }
                while (true) {
                    val output = synchronized(lock) {
                        while (!released && version == generation && freeOutputs.isEmpty()) lock.wait()
                        if (released) return
                        if (version != generation) null else freeOutputs.remove()
                    } ?: break
                    output.clear()
                    val available = StereoNative.take(context, output)
                    synchronized(lock) {
                        output.mode = mode; output.format = format
                        if (available && version == generation && output.timeUs >= outputStart) outputs.add(output)
                        else output.release()
                    }
                    if (!available) {
                        if (eos) synchronized(lock) {
                            while (!released && version == generation && freeOutputs.isEmpty()) lock.wait()
                            if (released) return
                            if (version == generation) freeOutputs.remove().also {
                                it.clear(); it.addFlag(C.BUFFER_FLAG_END_OF_STREAM); outputs.add(it)
                            }
                        }
                        break
                    }
                }
            }
        } catch (error: Throwable) {
            synchronized(lock) { failure = StereoDecodeException("Stereo decode failed: ${error.message}", error); lock.notifyAll() }
        }
    }
    companion object {
        const val MVC_MIME = "video/x-vistalyra-mvc"
        const val MVHEVC_MIME = "video/x-vistalyra-mvhevc"
    }
}

object StereoNative {
    init { System.loadLibrary("vistalyraStereo") }
    @JvmStatic external fun open(mvc: Boolean): Long
    @JvmStatic external fun feed(context: Long, input: java.nio.ByteBuffer?, size: Int, pts: Long, eos: Boolean)
    @JvmStatic external fun take(context: Long, output: VideoDecoderOutputBuffer): Boolean
    @JvmStatic external fun flush(context: Long)
    @JvmStatic external fun close(context: Long)
    @JvmStatic external fun eyeOrderUnknown(context: Long): Boolean
    @JvmStatic external fun render(data: java.nio.ByteBuffer, width: Int, height: Int, surface: android.view.Surface)
}
