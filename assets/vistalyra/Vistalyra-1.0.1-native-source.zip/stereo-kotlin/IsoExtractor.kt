package com.cineverse.vr.player

import android.content.Context
import android.net.Uri
import android.os.ParcelFileDescriptor
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.util.ParsableByteArray
import androidx.media3.extractor.*

class IsoTrack(val id: Int, val mime: String, val width: Int, val height: Int,
               val sampleRate: Int, val channels: Int, val initialization: ByteArray)
class IsoPacket(val id: Int, val timeUs: Long, val flags: Int, val data: ByteArray)
object IsoNative {
    init { System.loadLibrary("vistalyraStereo") }
    @JvmStatic external fun open(fd: Int): Long
    @JvmStatic external fun tracks(handle: Long): Array<IsoTrack>
    @JvmStatic external fun durationUs(handle: Long): Long
    @JvmStatic external fun read(handle: Long): IsoPacket?
    @JvmStatic external fun seek(handle: Long, timeUs: Long)
    @JvmStatic external fun close(handle: Long)
}

/** Single-clip, unencrypted Blu-ray UDF images; no disc menus or decryption. */
@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
class IsoExtractor(private val context: Context, private val uri: Uri) : Extractor {
    private var descriptor: ParcelFileDescriptor? = null
    private var handle = 0L
    private val outputs = mutableMapOf<Int, TrackOutput>()
    private var desiredTimeUs = 0L
    private lateinit var extractorOutput: ExtractorOutput
    override fun sniff(input: ExtractorInput) = true // Created only for a selected ISO filename; open validates UDF.
    override fun init(output: ExtractorOutput) {
        extractorOutput = output
    }
    private fun openSource(output: ExtractorOutput) {
        try {
            descriptor = if (uri.scheme == "file") ParcelFileDescriptor.open(java.io.File(checkNotNull(uri.path)), ParcelFileDescriptor.MODE_READ_ONLY)
                else context.contentResolver.openFileDescriptor(uri, "r")
            handle = IsoNative.open(checkNotNull(descriptor).fd)
            IsoNative.tracks(handle).forEach { track ->
                val video = track.mime.startsWith("video/")
                val format = Format.Builder().setId(track.id).setSampleMimeType(track.mime)
                if (video) {
                    format.setWidth(track.width).setHeight(track.height)
                    if (track.mime == StereoDecoder.MVC_MIME) format.setStereoMode(C.STEREO_MODE_LEFT_RIGHT)
                } else {
                    format.setSampleRate(track.sampleRate).setChannelCount(track.channels)
                    if (track.mime == "audio/raw") format.setPcmEncoding(C.ENCODING_PCM_16BIT)
                }
                if (track.initialization.isNotEmpty()) format.setInitializationData(listOf(track.initialization))
                outputs[track.id] = output.track(track.id, if (video) C.TRACK_TYPE_VIDEO else C.TRACK_TYPE_AUDIO).also { it.format(format.build()) }
            }
            output.endTracks()
            output.seekMap(object : SeekMap {
                override fun isSeekable() = true
                override fun getDurationUs() = IsoNative.durationUs(handle).takeIf { it > 0 } ?: C.TIME_UNSET
                override fun getSeekPoints(timeUs: Long) = SeekMap.SeekPoints(SeekPoint(timeUs, 0))
            })
            if (desiredTimeUs > 0) IsoNative.seek(handle, desiredTimeUs)
        } catch (error: Throwable) {
            release()
            throw java.io.IOException("Cannot open Blu-ray image: ${error.message}", error)
        }
    }
    override fun read(input: ExtractorInput, seekPosition: PositionHolder): Int {
        try {
            if (handle == 0L) openSource(extractorOutput)
            val packet = IsoNative.read(handle) ?: return Extractor.RESULT_END_OF_INPUT
            outputs[packet.id]?.let { target ->
                target.sampleData(ParsableByteArray(packet.data), packet.data.size)
                target.sampleMetadata(packet.timeUs, packet.flags, packet.data.size, 0, null)
            }
            return Extractor.RESULT_CONTINUE
        } catch (error: Throwable) { throw java.io.IOException("Blu-ray stream failed: ${error.message}", error) }
    }
    override fun seek(position: Long, timeUs: Long) {
        desiredTimeUs = timeUs
        if (handle != 0L) IsoNative.seek(handle, timeUs)
    }
    override fun release() {
        if (handle != 0L) { IsoNative.close(handle); handle = 0 }
        descriptor?.close(); descriptor = null; outputs.clear()
    }
}
