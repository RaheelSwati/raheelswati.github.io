# Code 30 matching codec sources and relinking

This bundle accompanies the local Quest 1.0.1/code 30 test candidate. It must
be made accessible alongside any public binary distribution. It contains the
unmodified FFmpeg 9.0.2 and libudfread source snapshots, the modified JNI
sources, matching JNI objects and static FFmpeg archives. The audio component's
separate exact FFmpeg 6.1.6 bundle is included unchanged.

To replace the LGPL FFmpeg video library, extract ffmpeg-9.0.2-source.tar.gz as
native-codecs/ffmpeg-video, rebuild using build-video.sh and an Android NDK
ARM64/API 32 toolchain, then substitute its libavcodec.a, libavformat.a and
libavutil.a in the following command. The matching objects allow relinking
without needing other Vistalyra source files. Replace libudfread.so independently
using Build-UdfRead.ps1 and the supplied libudfread sources.

Run from this bundle's directory with the NDK compiler path substituted:

```text
clang++ --target=aarch64-linux-android32 -shared stereo_jni.o iso_jni.o libedge264mvc.so libudfread.so libavformat.a libavcodec.a libavutil.a -landroid -llog -lz -lm -Wl,--exclude-libs,ALL -Wl,-z,max-page-size=16384 -Wl,-soname,libvistalyraStereo.so -static-libstdc++ -o libvistalyraStereo.so
```

Replace lib/arm64-v8a/libvistalyraStereo.so and/or libudfread.so in the APK,
align and sign with your own key, then install the modified APK. Android requires
uninstalling the original signed package before installing a differently signed
package (back up app data first). Keep the LGPL notices. Reverse engineering
necessary to debug modifications to the LGPL libraries is permitted.

MVC library source/build instructions are in edge264-mvc-source.tar.gz and
Build-AndroidDecoder.ps1. AV1 modified adapter sources and Apache notices are
included; upstream versions and pins are recorded in the native-codecs README.
No GPL or nonfree FFmpeg codecs are enabled in these binaries.
