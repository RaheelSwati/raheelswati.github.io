# FFmpeg audio fallback

The original FFmpeg 6.1.6 integration provides Media3 audio fallback.
Code 30 additionally introduces an isolated FFmpeg 9.0.2 multiview HEVC decoder,
edge264-mvc stereo decoding, libudfread single-clip ISO extraction and libgav1 AV1.
It does not implement Blu-ray menus, encryption removal or multi-clip playlists.
AVI demux/playback uses Media3's built-in extractor, not FFmpeg video decoding.
Hardware audio decoding remains preferred through extension renderer mode ON.

## Reproducible sources

FFmpeg n6.1.6 is pinned to
`f1e3a2bf7a2f2cde936d1ed97f09a26853d20125` from
https://github.com/FFmpeg/FFmpeg . Java and JNI adapters are from the official
AndroidX Media3 1.5.1 tag: https://github.com/androidx/media/tree/1.5.1/libraries/decoder_ffmpeg .
The JNI source is `ffmpeg_jni.cc`; Java sources are in
`../media-engine/src/main/java/androidx/media3/decoder/ffmpeg`.

Run `build-audio.sh` in Git Bash with Unity 6000.0.72f1's Android NDK available
through the local `ndk` junction and GNU make in `build-tools/usr/bin`.
The script captures the decoder list, API 32, ARM64, dynamic linking and
16 KB linker configuration. GPL, nonfree and version3 are disabled.
Do not recursively delete the NDK junction.

## Distribution gate

FFmpeg is LGPL 2.1 or later; Media3 is Apache 2.0. Their license texts are
packaged in assets/licenses and accessible under Playback settings.
Before releasing binaries, publish the matching source archive including this
script, JNI/Java adapters and configuration, with an accessible source link in
the product notices/support page. Upstream homepages alone do not substitute
for distributing the exact corresponding sources. Keep shared libraries
separate and preserve source and build provenance with each release.

## Validation limits

On October 11, packaged ARM64 JNI decoded synthetic AC-3, E-AC-3, DTS and TrueHD
fixtures into non-silent PCM, including after reset, on the Android XR emulator
with ARM64 translation. AVI/H.264 first-frame rendering also passed. Tests live
under app/src/androidTest; regenerate fixtures with tools/Create-CodecFixtures.ps1.
These checks do not establish Quest performance, long-playback A/V sync,
multichannel downmix quality or automatic renderer selection in real movies.

Local JNI modifications preserve TrueHD output mode/channel layout before freeing
the context, initialize TrueHD/MLP container channel layout, and route decoder
errors to Android logs. Distribute this exact modified JNI source with binaries.

## Code 30 video sources and build

FFmpeg 9.0.2 commit `946fcce07b6dcd0331c8cc609192aeff5e1924f8` is built
by `build-video.sh` with GPL and nonfree disabled. Static library symbols are
hidden inside `libvistalyraStereo.so`, separate from the FFmpeg audio ABI.
`Build-StereoBridge.ps1` retains the JNI object files for LGPL relinking.
`Build-UdfRead.ps1` builds libudfread commit
`b0bc6957e7e07d5f35391f210596d9eb71cffdd9` as a replaceable shared library.
`Build-Av1.ps1` builds libgav1 v0.19.0 with CPU Features 0.9.0 and Abseil
20230802.1. ARM64 feature detection, 10-bit SDR conversion and EOS lifetime
fixes are in the modified JNI/Java sources. HDR tone mapping is not implemented.
MVC uses https://github.com/jens-duttke/edge264-mvc commit
`e8f4b3b54e34d752c16760efa1e7ad966307eb2b` (BSD 3-Clause).

The code 30 corresponding-source bundle includes source snapshots, build scripts,
matching static archives and JNI object files. Publish that bundle and its source
link with any externally distributed code 30 binary. Local headset testing is
not public distribution. Do not reuse the code 29 audio-only bundle for code 30.
