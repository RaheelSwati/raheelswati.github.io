param([string]$NdkPath = "$PSScriptRoot/ndk")
$ErrorActionPreference = 'Stop'
$taskCompiler = Join-Path $NdkPath 'toolchains/llvm/prebuilt/windows-x86_64/bin/clang.exe'
$taskSources = @('default_blockinput','ecma167','udf_fs','udf_volume','udfread') | ForEach-Object { "$PSScriptRoot/libudfread/src/$_.c" }
& $taskCompiler --target=aarch64-linux-android32 -O2 -fPIC -shared -DHAVE_UNISTD_H=1 -DHAVE_FCNTL_H=1 -DHAVE_PTHREAD_H=1 -D_FILE_OFFSET_BITS=64 @taskSources '-Wl,-z,max-page-size=16384' '-Wl,-soname,libudfread.so' -o "$PSScriptRoot/libudfread.so"
if ($LASTEXITCODE -ne 0) { throw 'UDF reader build failed' }
Copy-Item "$PSScriptRoot/libudfread.so" "$PSScriptRoot/../media-engine/src/main/jniLibs/arm64-v8a/" -Force
