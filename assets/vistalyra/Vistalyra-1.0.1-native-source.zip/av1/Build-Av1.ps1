param([string]$SdkPath = 'C:/Program Files/Unity/Hub/Editor/6000.0.72f1/Editor/Data/PlaybackEngines/AndroidPlayer/SDK')
$ErrorActionPreference = 'Stop'
$taskCmake = Join-Path $SdkPath 'cmake/3.22.1/bin/cmake.exe'
$taskNinja = Join-Path $SdkPath 'cmake/3.22.1/bin/ninja.exe'
$taskBuild = Join-Path $PSScriptRoot 'av1/build-arm64'
$taskNdk = Join-Path $PSScriptRoot 'ndk'
& $taskCmake -S "$PSScriptRoot/av1" -B $taskBuild -G Ninja "-DCMAKE_MAKE_PROGRAM=$taskNinja" "-DCMAKE_TOOLCHAIN_FILE=$taskNdk/build/cmake/android.toolchain.cmake" -DANDROID_ABI=arm64-v8a -DANDROID_PLATFORM=android-32 -DANDROID_STL=c++_static -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=OFF -DBUILD_PIC=ON -DCPU_FEATURES_BUILD_TESTS=OFF -DCPU_FEATURES_BUILD_TOOLS=OFF -DLIBGAV1_ENABLE_TESTS=OFF -DLIBGAV1_ENABLE_EXAMPLES=OFF -DCMAKE_POLICY_DEFAULT_CMP0077=NEW
if ($LASTEXITCODE -ne 0) { throw 'AV1 configure failed' }
& $taskCmake --build $taskBuild -j4
if ($LASTEXITCODE -ne 0) { throw 'AV1 build failed' }
$taskDestination = Join-Path (Split-Path $PSScriptRoot -Parent) 'media-engine/src/main/jniLibs/arm64-v8a/libgav1JNI.so'
Copy-Item "$taskBuild/libgav1JNI.so" $taskDestination
& "$taskNdk/toolchains/llvm/prebuilt/windows-x86_64/bin/llvm-strip.exe" --strip-unneeded $taskDestination
if ($LASTEXITCODE -ne 0) { throw 'AV1 stripping failed' }
