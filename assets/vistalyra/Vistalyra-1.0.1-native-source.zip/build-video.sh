#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
root="$(pwd)"
toolchain="$root/ndk/toolchains/llvm/prebuilt/windows-x86_64"
export PATH="$root/build-tools/usr/bin:$PATH"
mkdir -p build-video-arm64 install-video-arm64
cd build-video-arm64
../ffmpeg-video/configure \
 --target-os=android --arch=aarch64 --cpu=armv8-a --enable-cross-compile \
 --cc="$toolchain/bin/clang.exe" --cxx="$toolchain/bin/clang++.exe" \
 --host-cc="$toolchain/bin/clang.exe" \
 --host-cflags="--target=aarch64-linux-android32 --sysroot=$toolchain/sysroot" \
 --host-ldflags="--target=aarch64-linux-android32 --sysroot=$toolchain/sysroot" \
 --ar="$toolchain/bin/llvm-ar.exe" --ranlib="$toolchain/bin/llvm-ranlib.exe" \
 --nm="$toolchain/bin/llvm-nm.exe" --strip="$toolchain/bin/llvm-strip.exe" \
 --sysroot="$toolchain/sysroot" \
 --extra-cflags="--target=aarch64-linux-android32 -fPIC -fvisibility=hidden" \
 --extra-ldflags="--target=aarch64-linux-android32 -Wl,-z,max-page-size=16384" \
 --prefix="$root/install-video-arm64" \
 --enable-static --disable-shared --enable-pic --disable-doc --disable-programs \
 --disable-autodetect --disable-everything --disable-avdevice --disable-avfilter \
 --disable-swresample --disable-network --disable-symver --disable-gpl --disable-nonfree \
 --enable-avformat --disable-swscale --enable-decoder=hevc,h264,pcm_bluray \
 --enable-parser=hevc,h264,aac,ac3,dca --enable-demuxer=mov,matroska,mpegts,h264,hevc --enable-protocol=file
make -j4
make install
