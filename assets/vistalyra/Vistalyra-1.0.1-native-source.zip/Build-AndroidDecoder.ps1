param(
    [string]$NdkPath = 'C:\Program Files\Unity\Hub\Editor\6000.0.72f1\Editor\Data\PlaybackEngines\AndroidPlayer\NDK'
)
$ErrorActionPreference = 'Stop'
$expectedCommit = 'e8f4b3b54e34d752c16760efa1e7ad966307eb2b'
$sourcePath = Join-Path $PSScriptRoot 'edge264-mvc'
$outputPath = Join-Path $PSScriptRoot 'output'
if (-not (Test-Path -LiteralPath $sourcePath)) {
    throw "Missing decoder source. Clone https://github.com/jens-duttke/edge264-mvc.git into $sourcePath and check out $expectedCommit."
}
$actualCommit = (& git -C $sourcePath rev-parse HEAD).Trim()
if ($LASTEXITCODE -ne 0 -or $actualCommit -ne $expectedCommit) { throw 'Decoder source revision differs from the reviewed pin.' }
if (& git -C $sourcePath status --porcelain) { throw 'Decoder source has local modifications; review before building.' }
$compilerDirectory = Join-Path $NdkPath 'toolchains\llvm\prebuilt\windows-x86_64\bin'
$compiler = Join-Path $compilerDirectory 'aarch64-linux-android32-clang.cmd'
if (-not (Test-Path -LiteralPath $compiler)) { throw 'Android ARM64 compiler not found.' }
New-Item -ItemType Directory -Path $outputPath -Force | Out-Null
$library = Join-Path $outputPath 'libedge264mvc.so'
$compilerFlags = @('-std=gnu11', '-O3', '-fwrapv', '-flax-vector-conversions', '-Wno-override-init',
    '-pthread', '-march=armv8-a+simd', '-fPIC', '-fvisibility=hidden', '-DEDGE264MVC_BUILD')
& $compiler @compilerFlags -shared (Join-Path $sourcePath 'src\edge264mvc.c') '-Wl,-z,max-page-size=16384' '-Wl,-soname,libedge264mvc.so' -o $library
if ($LASTEXITCODE -ne 0) { throw 'Decoder compilation failed.' }
& $compiler -std=gnu11 -O2 -pthread -I $sourcePath (Join-Path $sourcePath 'tests\api_check.c') $library '-Wl,-rpath,$ORIGIN' -o (Join-Path $outputPath 'mvc-api-check')
if ($LASTEXITCODE -ne 0) { throw 'Native API test compilation failed.' }
Copy-Item -LiteralPath (Join-Path $sourcePath 'LICENSE_BSD.txt') -Destination (Join-Path $outputPath 'LICENSE_BSD.txt')
& (Join-Path $compilerDirectory 'llvm-readelf.exe') -h -l $library | Set-Content -LiteralPath (Join-Path $outputPath 'elf-validation.txt')
if ($LASTEXITCODE -ne 0) { throw 'ELF inspection failed.' }
[ordered]@{
    source = 'https://github.com/jens-duttke/edge264-mvc'
    commit = $actualCommit
    license = 'BSD-3-Clause'
    target = 'Android ARM64 API 32'
    sha256 = (Get-FileHash -LiteralPath $library -Algorithm SHA256).Hash
    status = 'Compiled only; not packaged in the player or verified on a headset'
    remaining = @('Native API tests on device', 'MVC conformance streams with both eye hashes',
        'MKV/SSIF demux and timestamps', 'Media3 decoder adapter', 'Stereo compositor output',
        'Audio/video sync and seeking', 'Quest 2 sustained performance and thermal tests')
} | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $outputPath 'provenance.json')
Write-Output "Experimental ARM64 decoder and native API test compiled in $outputPath. No runtime support has been enabled."
